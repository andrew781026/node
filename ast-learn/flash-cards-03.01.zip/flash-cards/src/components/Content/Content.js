export const Content = ({ children }) => (
  <div className="content-container">{children}</div>
);
